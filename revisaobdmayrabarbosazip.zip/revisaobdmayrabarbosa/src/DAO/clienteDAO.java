
package DAO;
import codigofonte.cliente;
import conexao.conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class clienteDAO {
    public void inserircliente (cliente c){
        try {
            String SQL = "INSERT INTO mayra_barbosa.ator1(nome, telefone) VALUES (?,?,?)";
            Connection minhaConexao = conexao.getConexao();
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            comando.setString(1, c.getNome());
            comando.setString(2, c.getTelefone());
            int retorno = comando.executeUpdate();
            if(retorno>0){
                JOptionPane.showMessageDialog(null, "Nome " +c.getNome()+ " cadastrado com sucesso." );
            }
            else{
                JOptionPane.showMessageDialog(null, "Erro ao cadastrar o nome " +c.getNome()+ ", verifique seus dados.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(clienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private cliente pegaDados(ResultSet resultado){
        try {
            cliente atual=new cliente();
            atual.setNome(resultado.getString("nome"));
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(clienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
