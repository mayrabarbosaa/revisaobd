
package codigofonte;

public class cliente {
    private String nome;
    private String telefone;
    
    public cliente(){
        this.nome = "";
        this.telefone = "";
    }
    public cliente(String nome ,String telefone) {
        this.nome = "";
        this.telefone = telefone;
        
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    
}
