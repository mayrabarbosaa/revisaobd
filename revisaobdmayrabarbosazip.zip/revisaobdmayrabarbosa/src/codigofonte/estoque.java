package codigofonte;

public class estoque {
    private String livro;
    private String quantidade;
    
    public estoque(){
        this.livro = "";
        this.quantidade = "";
    }
    public estoque(String livro ,String quantidade) {
        this.livro = "";
        this.quantidade = "";
        
    }
    public String getLivro() {
        return livro;
    }

    public void setLivro(String livro) {
        this.livro = livro;
    }
    
    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }
}
